package ATMMACHINE;
import java.util.scanner;

class ATM{
    private double BankAccount;
    
    public BankAccount(double initalBalance) {
        this.balance = initalBalance;
    }
    
    public double getBalance(){
        return balance;
    }
    public void deposit(double amount){
        if(amount > 0){
            balance += amount;
            System.out.println("Deposit successful. new balance:" + balance);
        }else{
            System.out.println("Invalid amount Deposit.");
        }
    }
    public void Withdraw(double amount){
        in(amount > 0 && amount<= balance) {
            balance -= amount;
            System.out.println("withdraw successful. new balance:" + balance);
        } else {
        System.out.println("insufficient amount for withdrawal");
        }
    }
}
class ATMmachine{
    private BankAccount account;
    private Scanner scanner;
    
    public ATMmachine(BankAccount account){
        this.account = account;
        this.scanner = new Scanner(System.in);
    }
    public void showmenu(){
        System.out.println("1. Check Balance");
        System.out.println("2. Deposit");
        System.out.println("3. withdraw");
        System.out.println("4. Exit");
    }
    
    public void run(){
        
        int choice;
        do{
            showmenu();
            System.out.print("Enter your Choice" );
            Choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    CheckBalance();
                    break;
                case 2:
                    Deposit();
                    break;
                case 3:
                    withdraw();
                    break;
                case 4:
                    System.out.println("Thank you!! For Using the ATM");
                    break;
                    default:
                    System.out.println("Invalid choice. please select valid option");
            }
        }while (choice !=4);
    }
    private void CheckBalance(){
        System.out.println("Your current Balance is: " +amount.getBalance());
    }
    private void Deposit(){
        System.out.println("Enter the amount to deposit: ");
        double amount = scanner.nextDouble();
        account.deposit(amount);
    }
    private void withdraw(){
        System.out.println("Enter the amount to withdraw: ");
        double amount = scanner.nextDouble();
        account.withdraw(amount);
    }
}
public class ATMinter{
    public static void main(String[] args){
        System.out.println("welcome to the ATM");
        scanner sc = new Scanner (System.in);
        System.out.print("Enter your four digit Pin Number: ");
        int enteredpin = sc.nextInt();
        
        BankAccount useraccount = new BankAccount(1000.0);
        ATM atm = new ATM(userAccount);
        atm.run();
    }
}